/**
 * Activates or deactivates this `PollingSignal`.
 */
export interface PollingSignalActivateTrait {
  activate(active?: boolean): void;
}
