export interface PollingSignalReadFunction<GValue> {
  (): GValue;
}
