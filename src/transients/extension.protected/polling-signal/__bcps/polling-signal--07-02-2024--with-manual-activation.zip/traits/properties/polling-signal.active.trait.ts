/**
 * Return `true` if this `PollingSignal` is _active_.
 */
export interface PollingSignalActiveTrait {
  readonly active: boolean;
}
