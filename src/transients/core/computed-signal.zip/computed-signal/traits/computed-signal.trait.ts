import { type SignalTrait } from '../../signal/traits/signal.trait.js';

export interface ComputedSignalTrait<GValue> extends SignalTrait<GValue> {}
