export interface ComputationFunction<GValue> {
  (): GValue;
}
