export interface PollingSignalOnTrigger {
  (): void;
}
