export interface EffectCleanUpFunction {
  (): void;
}
