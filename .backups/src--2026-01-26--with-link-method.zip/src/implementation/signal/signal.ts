import { EQUAL_FUNCTION_STRICT_EQUAL, type EqualFunction } from '@xstd/equal-function';
import { type UndoFunction } from '@xstd/undo-function';
import {
  createReactiveSystem,
  type Link,
  ReactiveFlags,
  type ReactiveNode,
} from 'alien-signals/system';
import { type RunBatch } from '../../interfaces/batch/batch.js';
import { type ComputedSignal } from '../../interfaces/computed/computed-signal.js';
import { type RunComputed } from '../../interfaces/computed/constructor/computed-signal-constructor.js';
import { type RunEffect } from '../../interfaces/effect/effect.js';
import { type SignalOptions } from '../../interfaces/signal/constructor/signal-options.js';
import { type Signal } from '../../interfaces/signal/signal.js';
import { SIGNAL } from '../../interfaces/signal/signal.symbol.js';
import { type WritableSignal } from '../../interfaces/writable-signal/writable-signal.js';

// source: https://github.com/stackblitz/alien-signals/blob/master/src/index.ts

/* REACTIVE SYSTEM */

interface ReactiveValueNode<GValue> extends ReactiveNode {
  readonly equal: EqualFunction<GValue>;
}

interface SignalNode<GValue> extends ReactiveValueNode<GValue> {
  currentValue: GValue;
  pendingValue: GValue;

  readonlyOutputSignal: Signal<GValue> | undefined;
  unlink: UndoFunction | undefined;
}

interface ComputedNode<GValue> extends ReactiveValueNode<GValue> {
  readonly fn: RunComputed<GValue>;

  value: GValue | undefined;
}

interface EffectNode extends ReactiveNode {
  readonly fn: RunEffect;
}

let cycle: number = 0;
let batchDepth: number = 0;
let notifyIndex: number = 0;
let queuedLength: number = 0;
let activeSub: ReactiveNode | undefined;

const queued: (EffectNode | undefined)[] = [];

const { link, unlink, propagate, checkDirty, shallowPropagate } = createReactiveSystem({
  update(node: ReactiveValueNode<unknown>): boolean {
    if (node.depsTail !== undefined) {
      return updateComputedNode(node as ComputedNode<unknown>);
    } else {
      return updateSignalNode(node as SignalNode<unknown>);
    }
  },
  notify(node: EffectNode): void {
    let insertIndex: number = queuedLength;
    let firstInsertedIndex: number = insertIndex;

    do {
      node.flags &= ~ReactiveFlags.Watching;
      queued[insertIndex++] = node;
      node = node.subs?.sub as EffectNode;
      if (node === undefined || !(node.flags & ReactiveFlags.Watching)) {
        break;
      }
    } while (true);

    queuedLength = insertIndex;

    while (firstInsertedIndex < --insertIndex) {
      const left: EffectNode | undefined = queued[firstInsertedIndex];
      queued[firstInsertedIndex++] = queued[insertIndex];
      queued[insertIndex] = left;
    }
  },
  unwatched(node: ReactiveNode): void {
    if (!(node.flags & ReactiveFlags.Mutable)) {
      unwatchNode(node);
    } else if (node.depsTail !== undefined) {
      node.depsTail = undefined;
      node.flags = ReactiveFlags.Mutable | ReactiveFlags.Dirty;
      purgeDeps(node);
    }
  },
});

function setActiveSub(sub: ReactiveNode | undefined): ReactiveNode | undefined {
  const prevSub: ReactiveNode | undefined = activeSub;
  activeSub = sub;
  return prevSub;
}

function startBatch(): void {
  ++batchDepth;
}

function endBatch(): void {
  if (!--batchDepth) {
    flush();
  }
}

function updateSignalNode(node: SignalNode<any>): boolean {
  node.flags = ReactiveFlags.Mutable;
  return !node.equal(node.currentValue, (node.currentValue = node.pendingValue));
}

function updateComputedNode(node: ComputedNode<any>): boolean {
  ++cycle;
  node.depsTail = undefined;
  node.flags = ReactiveFlags.Mutable | ReactiveFlags.RecursedCheck;
  const prevSub: ReactiveNode | undefined = setActiveSub(node);
  try {
    return !node.equal(node.value, (node.value = node.fn()));
  } finally {
    activeSub = prevSub;
    node.flags &= ~ReactiveFlags.RecursedCheck;
    purgeDeps(node);
  }
}

function runEffectNode(node: EffectNode): void {
  const flags: ReactiveFlags = node.flags;
  if (
    flags & ReactiveFlags.Dirty ||
    (flags & ReactiveFlags.Pending && checkDirty(node.deps!, node))
  ) {
    ++cycle;
    node.depsTail = undefined;
    node.flags = ReactiveFlags.Watching | ReactiveFlags.RecursedCheck;
    const prevSub: ReactiveNode | undefined = setActiveSub(node);
    try {
      node.fn();
    } finally {
      activeSub = prevSub;
      node.flags &= ~ReactiveFlags.RecursedCheck;
      purgeDeps(node);
    }
  } else {
    node.flags = ReactiveFlags.Watching;
  }
}

function unwatchNode(node: ReactiveNode): void {
  node.depsTail = undefined;
  node.flags = ReactiveFlags.None;
  purgeDeps(node);
  const sub: Link | undefined = node.subs;
  if (sub !== undefined) {
    unlink(sub);
  }
}

function purgeDeps(sub: ReactiveNode): void {
  const depsTail: Link | undefined = sub.depsTail;
  let dep: Link | undefined = depsTail !== undefined ? depsTail.nextDep : sub.deps;
  while (dep !== undefined) {
    dep = unlink(dep, sub);
  }
}

function flush(): void {
  while (notifyIndex < queuedLength) {
    const effect: EffectNode = queued[notifyIndex]!;
    queued[notifyIndex++] = undefined;
    runEffectNode(effect);
  }
  notifyIndex = 0;
  queuedLength = 0;
}

/* IMPLEMENTATIONS */

// SIGNAL

export function signal<GValue>(
  initialValue: GValue,
  { equal = EQUAL_FUNCTION_STRICT_EQUAL }: SignalOptions<GValue> = {},
): WritableSignal<GValue> {
  const node: SignalNode<GValue> = {
    equal,
    readonlyOutputSignal: undefined,
    unlink: undefined,

    currentValue: initialValue,
    pendingValue: initialValue,
    subs: undefined,
    subsTail: undefined,
    flags: ReactiveFlags.Mutable,
  };

  const get = (): GValue => {
    if (node.flags & ReactiveFlags.Dirty) {
      if (updateSignalNode(node)) {
        const subs: Link | undefined = node.subs;
        if (subs !== undefined) {
          shallowPropagate(subs);
        }
      }
    }
    let sub: ReactiveNode | undefined = activeSub;
    while (sub !== undefined) {
      if (sub.flags & (ReactiveFlags.Mutable | ReactiveFlags.Watching)) {
        link(node, sub, cycle);
        break;
      }
      sub = sub.subs?.sub;
    }
    return node.currentValue;
  };

  return Object.assign(get, {
    [SIGNAL]: undefined,
    set: (value: GValue): void => {
      if (activeSub !== undefined) {
        throw new Error('Signal value cannot be set while a computation/effect is running.');
      }

      if (node.unlink !== undefined) {
        throw new Error('Signal linked.');
      }

      if (!node.equal(node.pendingValue, (node.pendingValue = value))) {
        node.flags = ReactiveFlags.Mutable | ReactiveFlags.Dirty;
        const subs: Link | undefined = node.subs;
        if (subs !== undefined) {
          propagate(subs);
          if (!batchDepth) {
            flush();
          }
        }
      }
    },
    asReadonly: (): Signal<GValue> => {
      if (node.readonlyOutputSignal === undefined) {
        node.readonlyOutputSignal = Object.assign(
          (): GValue => {
            return get();
          },
          {
            [SIGNAL]: undefined,
          },
        );
      }

      return node.readonlyOutputSignal!;
    },
    get linked(): boolean {
      return node.unlink !== undefined;
    },
    link: (signal: Signal<GValue>): UndoFunction => {
      if (activeSub !== undefined) {
        throw new Error('Signal value cannot be linked while a computation/effect is running.');
      }

      if (node.unlink !== undefined) {
        throw new Error('Signal already linked.');
      }

      let active: boolean = true;

      node.unlink = (): void => {
        if (active) {
          active = false;
          node.unlink = undefined;
          stopEffect();
        }
      };

      // naive implementation
      const stopEffect: UndoFunction = effect((): void => {
        const value: GValue = signal();

        untracked((): void => {
          if (!node.equal(node.pendingValue, (node.pendingValue = value))) {
            node.flags = ReactiveFlags.Mutable | ReactiveFlags.Dirty;
            const subs: Link | undefined = node.subs;
            if (subs !== undefined) {
              propagate(subs);
              if (!batchDepth) {
                flush();
              }
            }
          }
        });
      });

      return node.unlink;
    },
  } satisfies Omit<WritableSignal<GValue>, ''>);
}

// COMPUTED

export function computed<GValue>(
  fn: RunComputed<GValue>,
  { equal = EQUAL_FUNCTION_STRICT_EQUAL }: SignalOptions<GValue> = {},
): ComputedSignal<GValue> {
  const node: ComputedNode<GValue> = {
    equal,
    fn,
    value: undefined,
    subs: undefined,
    subsTail: undefined,
    deps: undefined,
    depsTail: undefined,
    flags: ReactiveFlags.None,
  };

  return Object.assign(
    (): GValue => {
      const flags: ReactiveFlags = node.flags;
      if (
        flags & ReactiveFlags.Dirty ||
        (flags & ReactiveFlags.Pending &&
          (checkDirty(node.deps!, node) || ((node.flags = flags & ~ReactiveFlags.Pending), false)))
      ) {
        if (updateComputedNode(node)) {
          const subs: Link | undefined = node.subs;
          if (subs !== undefined) {
            shallowPropagate(subs);
          }
        }
      } else if (!flags) {
        node.flags = ReactiveFlags.Mutable | ReactiveFlags.RecursedCheck;
        const prevSub: ReactiveNode | undefined = setActiveSub(node);
        try {
          node.value = node.fn();
        } finally {
          activeSub = prevSub;
          node.flags &= ~ReactiveFlags.RecursedCheck;
        }
      } else {
        throw new Error('Computation loop detected.');
      }
      const sub: ReactiveNode | undefined = activeSub;
      if (sub !== undefined) {
        link(node, sub, cycle);
      }
      return node.value!;
    },
    {
      [SIGNAL]: undefined,
    },
  );
}

// EFFECT

export function effect(fn: RunEffect): UndoFunction {
  const node: EffectNode = {
    fn,
    subs: undefined,
    subsTail: undefined,
    deps: undefined,
    depsTail: undefined,
    flags: ReactiveFlags.Watching | ReactiveFlags.RecursedCheck,
  };

  const prevSub: ReactiveNode | undefined = setActiveSub(node);

  if (prevSub !== undefined) {
    link(node, prevSub, 0);
  }

  try {
    node.fn();
  } finally {
    activeSub = prevSub;
    node.flags &= ~ReactiveFlags.RecursedCheck;
  }

  return (): void => {
    if (node.flags !== ReactiveFlags.None) {
      unwatchNode(node);
    }
  };
}

// BATCH

export function batch<GReturn>(fn: RunBatch<GReturn>): GReturn {
  startBatch();
  try {
    return fn();
  } finally {
    endBatch();
  }
}

// UNTRACKED

export function untracked<GReturn>(fn: RunBatch<GReturn>): GReturn {
  const prevSub: ReactiveNode | undefined = setActiveSub(undefined);
  try {
    return fn();
  } finally {
    activeSub = prevSub;
  }
}
