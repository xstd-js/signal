import { type Signal } from '../signal/signal.js';

export interface ComputedSignal<GValue> extends Signal<GValue> {}
