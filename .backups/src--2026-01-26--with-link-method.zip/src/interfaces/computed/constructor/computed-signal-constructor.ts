import { type SignalOptions } from '../../signal/constructor/signal-options.js';
import { type ComputedSignal } from '../computed-signal.js';

export interface RunComputed<GValue> {
  (): GValue;
}

export interface ComputedSignalConstructor {
  <GValue>(fn: RunComputed<GValue>, options?: SignalOptions<GValue>): ComputedSignal<GValue>;
}
