import { SIGNAL } from './signal.symbol.js';

export interface Signal<GValue> {
  (): GValue;

  [SIGNAL]: unknown;
}
