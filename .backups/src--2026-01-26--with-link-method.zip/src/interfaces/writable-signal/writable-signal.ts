import { type UndoFunction } from '@xstd/undo-function';
import { type Signal } from '../signal/signal.js';

export interface WritableSignal<GValue> extends Signal<GValue> {
  set(value: GValue): void;
  asReadonly(): Signal<GValue>;

  // linked to
  readonly linked: boolean;

  link(signal: Signal<GValue>): UndoFunction;
}
