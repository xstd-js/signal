import { type SignalOptions } from '../../signal/constructor/signal-options.js';
import { type WritableSignal } from '../writable-signal.js';

export interface WritableSignalConstructor {
  <GValue>(initialValue: GValue, options?: SignalOptions<GValue>): WritableSignal<GValue>;
}
