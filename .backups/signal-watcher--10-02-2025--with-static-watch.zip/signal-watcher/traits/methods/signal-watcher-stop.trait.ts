/**
 * Stops this SignalWatcher.
 */
export interface SignalWatcherStopTrait {
  stop(): void;
}
