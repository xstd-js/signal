import { type SignalWatcherStopTrait } from './methods/signal-watcher-stop.trait.js';

export interface SignalWatcherTrait extends SignalWatcherStopTrait, Disposable {}
