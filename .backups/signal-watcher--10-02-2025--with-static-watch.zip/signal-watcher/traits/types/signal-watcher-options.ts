export interface SignalWatcherOptions {
  readonly skipCurrentValue?: boolean;
}
