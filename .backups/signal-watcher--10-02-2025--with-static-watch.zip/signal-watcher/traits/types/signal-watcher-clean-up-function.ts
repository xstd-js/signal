export interface SignalWatcherCleanUpFunction {
  (): void;
}
