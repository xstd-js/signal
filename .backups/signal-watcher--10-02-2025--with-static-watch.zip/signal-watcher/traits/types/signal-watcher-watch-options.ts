import { type SignalWatcherOnErrorFunction } from './signal-watcher-on-error-function.js';
import { type SignalWatcherOnValueFunction } from './signal-watcher-on-value-function.js';
import { type SignalWatcherOptions } from './signal-watcher-options.js';

export interface SignalWatcherWatchOptions<GValue> extends SignalWatcherOptions {
  readonly value: SignalWatcherOnValueFunction<GValue>;
  readonly error?: SignalWatcherOnErrorFunction;
}
